GANPATI WEBSITE
Open index.html in Chrome.

Everything is now inside ONE HTML FILE, so the colours and animations do not depend on a separate CSS file.

Your address and WhatsApp number are already included.
